using Notero.MidiGameplay.Core;
using Notero.Raindrop;

namespace BU.MidiGameplay
{
    public class DemoRaindropNoteController : BaseRaindropNoteController, IMusicNotationControllable
    {
    }
}