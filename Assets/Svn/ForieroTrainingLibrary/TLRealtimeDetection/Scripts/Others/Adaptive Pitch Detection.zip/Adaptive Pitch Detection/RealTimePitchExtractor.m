function [freqArray, spectrumMatrix, autocorrMatrix] = ...
    RealTimePitchExtractor(runMode,Fs,N,xRangeInSeconds,...
        endPlotSwitch,quadInterpolFFT,quadInterpolAutocorr,fileInput)
% RealTimePitchExtractor(Fs,nCh,N,xRangeInSeconds)
% Created by Osborn Fong, April 2016
% Inputs: 
%   runMode - Choose either 'fft', 'autocorr' or 'adaptive'
%       'fft' option detects pitch based on fft method
%       'autocorr' option detects pitch based on autocorrelation method
%       'adaptive' option auto-selects either fft or autocorrelation method
%       based on the frequency of the detected fundamental to increase the
%       resolution
%   Fs - Sample rate
%   N - Sample Length of Frame
%   xRangeInSeconds - Length in time of live plot (x-axis)
%   endPlotSwitch - Display plot after detection routine stopped showing
%       detection of all pitches from start to finish.
%   quadInterpolFFT - 1 for enabling quadratic interpolation for FFT
%       procedure
%   quadInterpolAutocorr - 1 for enabling quadratic interpolation for ACF
%       procedure
%   fileInput - leave as blank ('') to enable live mic input or input the
%       file name and path of the audio signal to be read in and processed.
    
    % ======================
    % INITIALISATION & SETUP
    % ======================
    
    % Create and initialise Audio Recorder object
    % -------------------------------------------
    if strcmp(fileInput,'') == 1
        AR = dsp.AudioRecorder(...
        'OutputNumOverrunSamples',true,... % If buffer overrun, show amount
        'SampleRate',Fs,...
        'NumChannels',1,... % Set to only record from 1 channel (mono)
        'SamplesPerFrame',N...
        );

    else
        AR = dsp.AudioFileReader(...
        'Filename',fileInput,... % Filename of audio file to be read in
        'SamplesPerFrame',N...
        );
    end

    
    % Create and initialise Audio Writer object to save input to file
    % ---------------------------------------------------------------
    
    AFW = dsp.AudioFileWriter('inputdata.wav','FileFormat', 'WAV');
    
    % Setting up Figure to plot results
    % ---------------------------------
    
    % Obtains monitor screen resolution
    set(0,'units','pixels'); 
    
    screeninfo = get(0,'screensize'); % The 3rd and 4th array 
    % element gives the x(horizontal) and y(vertical) dimensions 
    % respectively.
    screenX = screeninfo(3);
    screenY = screeninfo(4);
    figureDisplay = figure('keypressfcn',@(obj,ev) set(obj,'userdata',ev));
    figureDisplay.Units = 'pixels';
    
    % Initialise plot position and size
    figureDisplay.Position = [  ceil(screenX*0.1) ceil(screenY*0.2)...
                                ceil(screenX*0.8) ceil(screenY*0.7)];  
    line = animatedline('MaximumNumPoints',floor(xRangeInSeconds*Fs/N));
    
    % Y Axis set to Approx 20Hz to 20kHz
    ylim([1.3 4.3]); 
    xlabel('Sample Index');
    ylabel('log10(Frequency[Hz])');
    title('Live Frequency Tracking')
    
    % Initialising plot variables - index1, x and y:
    index1 = 1;
    % Creating array big enough for 1 hour of data (preallocating memory to
    % speed up process)
    x = zeros(1,ceil(Fs/N*60*60)); 
    y = zeros(1,ceil(Fs/N*60*60));
    
    % Setting up variables for key detection on figure to exit program
    stringcompare = 'return'; % This key will stop the pitch detection loop
    key = 'none';   % Initialise variable holding current key pressed
    
    % Initialise plot refresh timer to control plot refresh rate
    timerPlotRefresh = tic;
    plotRefreshPeriod = 0.01;
    
    % ===================================
    % PITCH EXTRACTION PROCEDURE COMMENCE
    % ===================================
    
    displayMessage = [  'Microphone is now recording. '... 
                        'Pitch detection runs until return key is '...
                        'pressed in figure.'  ];
    disp(displayMessage);
    msgbox(displayMessage);
    pause(1);
    
    % Selecting mode of operation for pitch detection
    if strcmp(runMode,'adaptive')==1
        selectProcessing = 'fft'; % Start with FFT
        % Calculate fft-autocorr crossover point
        fftResolution = Fs/N;
        autocorrResolution = Fs; % Arbitrary large value intialised
        crossoverDelay = 1;
        while autocorrResolution > fftResolution % Find intersecting point
            autocorrResolution = Fs/crossoverDelay - Fs/(crossoverDelay+1); 
            crossoverDelay = crossoverDelay + 1;
        end
        crossoverFrequency = Fs/autocorrResolution
        pause(1);
    elseif strcmp(runMode,'fft')==1
        selectProcessing = 'fft';
    elseif strcmp(runMode,'autocorr')==1
        selectProcessing = 'autocorr';
    else
        msgbox(...
            'Please use only fft, autocorr or adaptive as runMode options');
        key = 'return'; % Force loop to not run by simulating return press.
    end
    
    % Calculating Autocorrelation weightings
    autocorrWeightingVector = 0:N-1;
    autocorrWeighting = N ./ (N - autocorrWeightingVector);
    
    % Extract pitch from audio buffer until return key is pressed
    while strcmp(stringcompare,key)==0
        
        % Access Audio Buffer
        % -------------------
        % Read in from audio buffer
    	[audioIn,nOverrun] = step(AR);
        % Read audio into audiofilewriter to save audio as WAV
        step(AFW,audioIn);
        
        if strcmp(selectProcessing,'fft')==1
            
            % FFT Procedure
            % -------------
            timerFFT = tic; % Begin timing fft runtime
            
            % Compute Complex FFT
            complexFFT = fft(audioIn);
            
            % Find the Magnitude Spectrum
            magFFT = abs(complexFFT);
            
            % Setting the frequency bin sizes
            N = length(audioIn);
            freqBins = 0:Fs/N:(Fs-1)/2;
            
            % Finding peak amplitude frequency
            [C,index] = max(magFFT(1:size(freqBins,2))); % Unused var C.
            freq = freqBins(index);
            
            % If quadInterpol is switched on, interpolate frequency result.
            if quadInterpolFFT == 1
                if index == 1 || index == (Fs-1)/2
                else
                    y1 = magFFT(index-1);
                    y2 = magFFT(index);
                    y3 = magFFT(index+1);
                    d = (y3-y1)/(2*(2*y2-y1-y3));
                    adjusted_index = index + d;
                    stepsize = 1/(N/Fs); % find spacing between bins
                    xsteps = 0:1/(N/Fs):(Fs-1)/2;
                    freq_quadinterpol = xsteps(index)+stepsize*d;
                    freq = freq_quadinterpol;
                end
            end
            % Store FFT data in matrix if exists, otherwise create a matrix
            % to store data
            if exist('spectrumMatrix','var') == 1
                spectrumMatrix(:,index1)=magFFT(:);
            else
                % Create matrix big enough for 1 hour of data
                spectrumMatrix = zeros(size(magFFT,1),ceil(Fs/N*60*60));
                spectrumMatrix(:,index1)=magFFT(:);
            end
            
            runTimeDetector = toc(timerFFT); % Stop timing fft runtime
            
            if strcmp(runMode,'adaptive')==1
                if freq < crossoverFrequency
                    selectProcessing = 'autocorr';
                end
            end
                
        elseif strcmp(selectProcessing,'autocorr')==1
            
            % Autocorrelation Procedure
            % -------------------------
            
            timerAutocorrelation = tic; % Begin timing autocorr. runtime
            autocorrInput = audioIn; % Read audio in
            autocorrOutput = zeros(N/2,1); % Initialise variable
            autocorrOutput = autocorr(autocorrInput,N-1);
            autocorrOutput = autocorrOutput .* autocorrWeighting';
            % Find local maxima
            [pks,autocorrPeaksArray] = findpeaks(autocorrOutput); 
            % If no peaks detected, assign a number so code
            % doesn't crash (but of course, this will give a false result)
            if isempty(autocorrPeaksArray) == 1
                autocorrPeaksArray = N-1;
            end
            
            % If quadInterpol is switched on, interpolate frequency result.
            if quadInterpolAutocorr == 1
                if autocorrPeaksArray(1) == 1 || autocorrPeaksArray(1) == (Fs-1)/2
                else
                    y1 = autocorrOutput(autocorrPeaksArray(1)-1);
                    y2 = autocorrOutput(autocorrPeaksArray(1));
                    y3 = autocorrOutput(autocorrPeaksArray(1)+1);
                    d = (y3-y1)/(2*(2*y2-y1-y3));
                    adjusted_index = autocorrPeaksArray(1) + d;
                    autocorrPeaksArray(1) = adjusted_index;
                end
            end    
            freq = Fs/(autocorrPeaksArray(1)-1);
            
            % Store autocorr. data in matrix if exists, otherwise create a 
            % matrix to store data
            if exist('autocorrMatrix','var') == 1
                autocorrMatrix(:,index1)=autocorrOutput(:);
            else
                % Create matrix big enough for 1 hour of data
                autocorrMatrix = zeros(size(autocorrOutput,1),...
                                    ceil(Fs/N*60*60));
                autocorrMatrix(:,index1)=autocorrOutput(:);
            end
            
            % Stop timing autocorrelation runtime
            runTimeDetector = toc(timerAutocorrelation); 
            
            if strcmp(runMode,'adaptive')==1
                if freq > crossoverFrequency
                    selectProcessing = 'fft';
                end
            end
            
        else
            disp('Error: Pitch Detection Method Undetermined')
            break
        end
        
        % Plot Procedure
        % --------------
        timerPlot = tic;
        x(index1) = index1;
        y(index1) = log10(freq);
        % Add new data point to animated line object
        addpoints(line,x(index1),abs(y(index1))); 
        % Update plot
        timeSinceLastPlotRefresh = toc(timerPlotRefresh); % check timer
            if timeSinceLastPlotRefresh > (plotRefreshPeriod)
                drawnow % update screen every 1/8 seconds
                timerPlotRefresh = tic; % reset timer after updating
            end
        index1 = index1+1;
        runTimePlot = toc(timerPlot);

        % Buffer overrun detection procedure
        % ----------------------------------
        if nOverrun > 0
            overrunMessage = ...
                [   'Audio recorder queue was overrun by %d samples.'...
                    'Decreasing plot refresh rate.\n'...
                    'Consider changing parameter N to improve ' ...
                    'performance.\n'];
            fprintf(overrunMessage,nOverrun);
            
            % Decrease plot refresh rate in an attempt to decrease runtime
            plotRefreshPeriod = plotRefreshPeriod + 0.01;
            plotRefreshRate = 1/plotRefreshPeriod;
            
            % Display new refresh rate on figure title
            newTitleName = sprintf(...
                [ 'Live Frequency Tracking [Screen Refresh Rate @ '...
                '%3.3fHz]' ], plotRefreshRate);
            title(newTitleName);
        end
        
        % Command Window output procedure
        % -------------------------------
        % Currently, command line is set to display the current detected
        % fundamental frequency and the runtime of the fft and plotting
        % routines.
        if strcmp(selectProcessing,'fft')==1
            method = 'FFT';
        elseif strcmp(selectProcessing,'autocorr')==1
            method = 'autocorrelation';
        else
            method = '???';
        end
        fprintf('Freq: %5.3f(Hz) | Runtime: %s %.2e(s), Plot %.2e(s)\n',...
            freq, method, runTimeDetector, runTimePlot);
        
        % Key press detection procedure
        % ------------------------------
        % Check if enter key is pressed, if so, loop will end next
        % iteration.
        key = get(gcf,'CurrentKey');
                
        %
        if strcmp(fileInput,'') == 0
            if isDone(AR)
                displayMessage = [  'End of File. Please press '...
                                    'OK to terminate program.'];
                disp(displayMessage);
                uiwait(msgbox(displayMessage));
                stringcompare = key;
            end
        end
    end
    pause(1);
    % Returning array of frequencies [sample index, determined pitch]
    freqArray = [x(:),y(:)];
    if endPlotSwitch == 1
        figure();
        plot(1:index1,y(1:index1));
        xlabel('Sample Index')
        ylabel('log10(Frequency[Hz])');
        title('Frequency over Time of Captured Audio')
    end
    
    % Releasing Audio Objects created
    release(AR);
    release(AFW);
    
    % Return empty arrays for processing mode not used
    if exist('autocorrMatrix','var') == 0
        autocorrMatrix = [];
    end
    if exist('spectrumMatrix','var') == 0
        spectrumMatrix = [];
    end
    
    disp('Pitch detection terminated.'); 
    pause(1);
    close(1);

end