Fs = 44100;             % Default Sampling Freq. set to 44100Hz.
N = 2^12;               % Default frame size set to 2048 frame size (2^12). 
xRangeInSeconds = 35;   % Default plot time length set to 10 seconds.
endPlotSwitch = 1;      % Default end plot set to 0.
runMode = 'adaptive';   % Default processing mode set to adaptive.
quadInterpolFFT = 1;    % Default to use quadratic interpolation (set as 1)
quadInterpolAutocorr = 1;   % Same as above
fileInput = '';         % No file input ('') will result in using default 
                        % onboard mic as live input. Alternatively input
                        % the location of the file to be read in and
                        % processed.
                        % e.g.
                        % fileInput = 'Test Signals/SineSweepExp20.wav'
                        % fileInput = 'Test Signals...
                        %   /SteppedToneSeqence20-20kHz2sectone1secsilence.wav'

[freqArray, spectrumMatrix, autocorrMatrix] = ...
    RealTimePitchExtractor(runMode,Fs,N,xRangeInSeconds,...
        endPlotSwitch,quadInterpolFFT,quadInterpolAutocorr,fileInput);
    